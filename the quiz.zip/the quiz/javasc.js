const form=document.querySelector("form");
const theRightAnsar=['B','B','B','B'];
const thespan=document.querySelector("span");
const the_result=document.querySelector("div");

form.addEventListener("submit",e=>{
    
   e.preventDefault();

    let score=0;
    let the_currentAnsar=[form.q1.value,form.q2.value,form.q3.value,form.q4.value];
    
    the_currentAnsar.forEach((ans,index)=>{
        
        if(ans===theRightAnsar[index])
            score+=25;
        
        
    });
    
  

    
    the_result.style.display="block";
    
    scrollTo(0,0);
    
    let increas=0;
    
    const timer=setInterval(()=>{
        
        thespan.textContent=`${increas}%`;
        if(increas===score){
            
            clearInterval(timer);
        }else{
            
            increas++;
        }
        
    },10);
    
});

