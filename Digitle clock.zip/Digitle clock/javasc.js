const clock=document.querySelector('.clock');

const hours=document.querySelector('.hours');


const mintes=document.querySelector('.mintes');


const seconds=document.querySelector('.seconds');



let the_time=function(){
    
    const r=new Date();
    
    hours.textContent=r.getHours();
    mintes.textContent=r.getMinutes();
    seconds.textContent=r.getSeconds();
    
    
    
}
setInterval(the_time,1000);

